# Build arulSU from the original BakaSU APK

This repository package contains the original APK and a GitHub Actions workflow that decodes it with Apktool, replaces visible `BakaSU` text with `arulSU`, rebuilds it, and signs the output APK.

## Build on GitHub

1. Create a new GitHub repository.
2. Upload the contents of this ZIP (the APK file, `.github/workflows/build.yml`, and this README) to the repository's default branch.
3. Open **Actions** → **Build arulSU APK** → **Run workflow**.
4. When the workflow completes, open the run and download the **arulSU-apk** artifact.

## Important notes

- This changes visible text where `BakaSU` occurs in decoded text resources; review the workflow log to confirm it updated the app label. Some APKs store labels in compiled/binary resources or use a different label string, which may require a targeted resource edit.
- The rebuilt APK is signed with a newly generated temporary key. Android may not treat it as an update to an APK signed with a different key. Keep the key secure if you need to publish future updates signed with the same key; for repeatable signing, configure `KEYSTORE_PASSWORD` and `KEY_PASSWORD` repository secrets and adjust the workflow to use a persistent keystore.
- Rebuilding an APK does not guarantee all features will work. Test the output before relying on it.
